package com.example.ex1_diceroller

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    //Từ khóa lateinit báo hiệu với trình biên dịch Kotlin rằng biến sẽ được khởi tạo trước khi mã gọi bất kỳ hoạt động nào trên nó. Do đó chúng ta không cần khởi tạo biến về null ở đây, và chúng ta có thể xem nó như một biến không thể bằng null khi chúng ta sử dụng nó. Đó là cách tốt nhất để sử dụng lateinit với những trường mà giữ các view theo cách này.
    //Sử dụng từ khoá lateinit để tránh khai báo nó là null.
    lateinit var diceImage: ImageView
    lateinit var btnRoll: Button
    lateinit var btnClear: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // tham chiếu
        btnRoll = findViewById(R.id.btn_roll)
        diceImage = findViewById(R.id.dice_image)
        btnClear = findViewById(R.id.btn_clear)

        btnRoll.setOnClickListener { rollDice() }
        btnClear.setOnClickListener { clearRollDice() }
    }

    // 　khởi tạo random 1 lần click trong khoảng từ 1-6

    private fun rollDice(){
        diceImage.setImageResource(getRandomDiceImage())
        btnClear.visibility = View.VISIBLE
    }


    private fun getRandomDiceImage(): Int{
        val randomInt = (1..6).random()

        return when(randomInt){
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }

    }

    private fun clearRollDice(){
        diceImage.setImageResource(getClearDiceImage())
        btnClear.visibility = View.GONE
    }

    private fun getClearDiceImage(): Int{
        return R.drawable.empty_dice
    }
}